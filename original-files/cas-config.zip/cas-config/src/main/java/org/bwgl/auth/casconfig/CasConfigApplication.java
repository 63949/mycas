package org.bwgl.auth.casconfig;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CasConfigApplication {

	public static void main(String[] args) {
		SpringApplication.run(CasConfigApplication.class, args);
	}
}
